/**
 * Android Parent App (Dashboard)
 * 
 * Implementation Details:
 * 1. Real-time Listeners: Attach to Firebase nodes.
 * 2. RecyclerView: Display message list with app icons.
 */

package com.guardian.parent

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.activity_main.* // Simplified for example

data class Message(
    val id: String = "",
    val sender: String = "",
    val text: String = "",
    val packageName: String = "",
    val timestamp: Long = 0
)

class MainActivity : AppCompatActivity() {

    private lateinit var database: DatabaseReference
    private val messageList = mutableListOf<Message>()
    private lateinit var adapter: MessageAdapter // Custom Adapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize Firebase
        database = FirebaseDatabase.getInstance().getReference("devices/child_device_01/messages")

        setupRecyclerView()
        startListening()
    }

    private fun setupRecyclerView() {
        adapter = MessageAdapter(messageList)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
    }

    private fun startListening() {
        database.limitToLast(50).addChildEventListener(object : ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                val message = snapshot.getValue(Message::class.java)
                if (message != null) {
                    messageList.add(0, message) // Add to top
                    adapter.notifyItemInserted(0)
                }
            }

            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {}
            override fun onChildRemoved(snapshot: DataSnapshot) {}
            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {}
            override fun onCancelled(error: DatabaseError) {
                // Handle permission or network errors
            }
        })
    }
}
