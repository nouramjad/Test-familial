package com.guardian.monitor

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.guardian.monitor.databinding.ActivityMainBinding
import com.google.firebase.database.*

/**
 * Parent Dashboard Activity
 * Displays real-time logs from the child device
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var db: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = FirebaseDatabase.getInstance().getReference("monitoring/child_dev_primary/logs")
        
        setupRealtimeListener()
    }

    private fun setupRealtimeListener() {
        db.limitToLast(20).addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                // Here you would update your UI/Adapter
                // For demonstration, we just log the count
                val count = snapshot.childrenCount
                binding.statusText.text = "Monitoring Active: $count messages received"
            }

            override fun onCancelled(error: DatabaseError) {
                binding.statusText.text = "Error: ${error.message}"
            }
        })
    }
}
