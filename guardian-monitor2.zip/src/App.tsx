/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { 
  MessageSquare, 
  Smartphone, 
  ShieldCheck, 
  Bell, 
  Search, 
  Filter, 
  MoreVertical, 
  CheckCircle2,
  AlertCircle,
  Clock,
  User,
  History,
  LayoutDashboard,
  Settings,
  Phone
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { format } from 'date-fns';

// Utility for tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface Message {
  id: string;
  sender: string;
  text: string;
  packageName: string;
  timestamp: number;
  appName: string;
}

const MOCK_MESSAGES: Message[] = [
  {
    id: '1',
    sender: 'Sami',
    text: 'Hey, are you coming to the park?',
    packageName: 'com.whatsapp',
    appName: 'WhatsApp',
    timestamp: Date.now() - 1000 * 60 * 5,
  },
  {
    id: '2',
    sender: 'Teacher Sara',
    text: 'Don\'t forget your homework assignment for tomorrow.',
    packageName: 'org.telegram.messenger',
    appName: 'Telegram',
    timestamp: Date.now() - 1000 * 60 * 15,
  },
  {
    id: '3',
    sender: 'Ahmed',
    text: 'Check out this game!',
    packageName: 'com.facebook.orca',
    appName: 'Messenger',
    timestamp: Date.now() - 1000 * 60 * 60 * 2,
  },
  {
    id: '4',
    sender: '+20123456789',
    text: 'Your verification code is 4432',
    packageName: 'com.android.mms',
    appName: 'SMS',
    timestamp: Date.now() - 1000 * 60 * 60 * 5,
  }
];

export default function App() {
  const [messages, setMessages] = useState<Message[]>(MOCK_MESSAGES);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'history' | 'devices' | 'settings'>('dashboard');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredMessages = messages.filter(m => 
    m.sender.toLowerCase().includes(searchQuery.toLowerCase()) || 
    m.text.toLowerCase().includes(searchQuery.toLowerCase()) ||
    m.appName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex h-screen bg-[#F8F9FA] text-[#1A1C1E] font-sans overflow-hidden">
      {/* Sidebar */}
      <aside className="w-72 bg-white border-r border-[#E1E2E4] flex flex-col shrink-0">
        <div className="p-6 flex items-center gap-3">
          <div className="w-10 h-10 bg-[#005FB4] rounded-xl flex items-center justify-center text-white shadow-lg shadow-blue-100">
            <ShieldCheck size={24} />
          </div>
          <div>
            <h1 className="font-bold text-lg leading-tight">Guardian</h1>
            <p className="text-xs text-[#5E6064] font-medium tracking-wide uppercase">Monitor</p>
          </div>
        </div>

        <nav className="flex-1 px-4 py-4 space-y-1">
          <NavItem 
            icon={<LayoutDashboard size={20} />} 
            label="Dashboard" 
            active={activeTab === 'dashboard'} 
            onClick={() => setActiveTab('dashboard')} 
          />
          <NavItem 
            icon={<History size={20} />} 
            label="Activity Log" 
            active={activeTab === 'history'} 
            onClick={() => setActiveTab('history')} 
          />
          <NavItem 
            icon={<Smartphone size={20} />} 
            label="Child Devices" 
            active={activeTab === 'devices'} 
            onClick={() => setActiveTab('devices')} 
          />
          <NavItem 
            icon={<Settings size={20} />} 
            label="Settings" 
            active={activeTab === 'settings'} 
            onClick={() => setActiveTab('settings')} 
          />
        </nav>

        <div className="p-4 border-t border-[#E1E2E4] bg-[#FBFBFC]">
          <div className="flex items-center gap-3 p-3 rounded-xl bg-white border border-[#E1E2E4]">
            <div className="w-10 h-10 rounded-full bg-[#E3E2E6] flex items-center justify-center">
              <User size={20} className="text-[#44474B]" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold truncate">Parent Account</p>
              <p className="text-xs text-[#5E6064] truncate">Free Spark Plan</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-16 bg-white border-b border-[#E1E2E4] px-8 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-4 text-sm font-medium text-[#44474B]">
            <span className="flex items-center gap-1.5 text-[#005FB4] bg-[#D3E4FF] px-3 py-1 rounded-full">
              <CheckCircle2 size={14} />
              Child Device: Active
            </span>
            <span className="flex items-center gap-1.5 bg-[#F1F0F4] px-3 py-1 rounded-full">
              <Clock size={14} />
              Last sync: Just now
            </span>
          </div>

          <div className="flex items-center gap-4">
            <button className="p-2 text-[#44474B] hover:bg-[#F1F0F4] rounded-full transition-colors relative">
              <Bell size={20} />
              <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </button>
            <div className="h-8 w-[1px] bg-[#E1E2E4]"></div>
            <button className="flex items-center gap-2 bg-[#005FB4] text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-[#004A8D] transition-colors shadow-sm">
              <Smartphone size={16} />
              Connect New Device
            </button>
          </div>
        </header>

        {/* Dashboard Grid */}
        <div className="flex-1 p-8 overflow-y-auto space-y-8">
          <section>
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-bold">Real-time Monitoring</h2>
                <p className="text-[#5E6064]">Tracking incoming chat notifications from connected devices.</p>
              </div>
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[#74777F]" size={18} />
                  <input 
                    type="text" 
                    placeholder="Search messages..." 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 pr-4 py-2 bg-white border border-[#C4C6CF] rounded-lg text-sm w-64 focus:outline-none focus:ring-2 focus:ring-[#005FB4] focus:border-transparent transition-all"
                  />
                </div>
                <button className="p-2 border border-[#C4C6CF] rounded-lg hover:bg-white transition-colors">
                  <Filter size={18} />
                </button>
              </div>
            </div>

            <div className="grid gap-4">
              {filteredMessages.map((msg) => (
                <div 
                  key={msg.id} 
                  className="bg-white border border-[#E1E2E4] rounded-2xl p-5 hover:border-[#005FB4] hover:shadow-sm transition-all group relative overflow-hidden"
                >
                  <div className="flex gap-4 items-start">
                    <div className={cn(
                      "w-12 h-12 rounded-xl flex items-center justify-center shrink-0",
                      msg.appName === 'WhatsApp' ? "bg-[#E7F3EF] text-[#25D366]" :
                      msg.appName === 'Telegram' ? "bg-[#E6F2F7] text-[#0088CC]" :
                      msg.appName === 'Messenger' ? "bg-[#F0E6F7] text-[#006AFF]" :
                      "bg-[#F2F0F4] text-[#74777F]"
                    )}>
                      <MessageSquare size={24} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="font-bold text-lg flex items-center gap-2">
                          {msg.sender}
                          <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-[#F1F0F4] text-[#5E6064]">
                            {msg.appName}
                          </span>
                        </h3>
                        <span className="text-xs text-[#74777F] font-medium">
                          {format(msg.timestamp, 'h:mm a')}
                        </span>
                      </div>
                      <p className="text-[#44474B] leading-relaxed">
                        {msg.text}
                      </p>
                    </div>
                    <button className="p-2 text-[#74777F] opacity-0 group-hover:opacity-100 transition-opacity">
                      <MoreVertical size={20} />
                    </button>
                  </div>
                  {/* Subtle accent line */}
                  <div className={cn(
                    "absolute left-0 top-0 bottom-0 w-1",
                    msg.appName === 'WhatsApp' ? "bg-[#25D366]" :
                    msg.appName === 'Telegram' ? "bg-[#0088CC]" :
                    msg.appName === 'Messenger' ? "bg-[#006AFF]" :
                    "bg-[#74777F]"
                  )}></div>
                </div>
              ))}

              {filteredMessages.length === 0 && (
                <div className="flex flex-col items-center justify-center py-20 bg-white border border-dashed border-[#C4C6CF] rounded-3xl text-[#74777F]">
                  <AlertCircle size={48} className="mb-4 opacity-20" />
                  <p className="font-medium">No messages found matching your search.</p>
                </div>
              )}
            </div>
          </section>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <StatCard 
              icon={<MessageSquare className="text-[#005FB4]" size={20} />} 
              label="Today's Messages" 
              value="124" 
              trend="+12% from yesterday"
            />
            <StatCard 
              icon={<Smartphone className="text-[#005FB4]" size={20} />} 
              label="Active Apps" 
              value="4" 
              trend="Monitoring 24/7"
            />
            <StatCard 
              icon={<ShieldCheck className="text-[#005FB4]" size={20} />} 
              label="System Health" 
              value="Optimal" 
              trend="No connection drops"
            />
          </div>
        </div>
      </main>
    </div>
  );
}

function NavItem({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all",
        active 
          ? "bg-[#D3E4FF] text-[#001C38] shadow-sm" 
          : "text-[#44474B] hover:bg-[#F1F0F4]"
      )}
    >
      {icon}
      {label}
    </button>
  );
}

function StatCard({ icon, label, value, trend }: { icon: React.ReactNode, label: string, value: string, trend: string }) {
  return (
    <div className="bg-white border border-[#E1E2E4] p-6 rounded-2xl shadow-sm">
      <div className="flex items-center gap-3 mb-4">
        <div className="p-2 bg-[#F1F0F4] rounded-lg">
          {icon}
        </div>
        <span className="text-sm font-semibold text-[#5E6064]">{label}</span>
      </div>
      <div className="text-3xl font-bold mb-1">{value}</div>
      <div className="text-xs font-medium text-[#006A6A]">{trend}</div>
    </div>
  );
}
